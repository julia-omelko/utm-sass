// open a single window
var window = Ti.UI.createWindow({
	backgroundColor: 'white'
});

var button = Ti.UI.createButton({
	height: 40,
   	width: Ti.Platform.displayCaps.platformWidth-40,
   	top: 20,
   	left: 20,
   	title: 'Open Unlock Window'
});

button.addEventListener('click',function() {
   unlockWindow.open();
});

window.add(button);
window.open();

// load the module
var unlockScreen = require('com.qbset.unlockscreen');
Ti.API.info("module is => " + unlockScreen);

// load the unlockScreen window
var unlockWindow = unlockScreen.loadWindow({
	// main properties for the module
	configLockScreen: {
		passCode: '1234',		 // set the passcode (string)
		attempts: 3,			 // zero for infinite attempts and no timeout (int)
		timeOut: 5000, 			 // time out in miliseconds after amount of incorrect attempts. Only when attempts is bigger then zero (int)
		timeOutMultiplier: 2,	 // after each set of attempts the time out is multiplied with this property (int)
		vibrateOnIncorrect: true // vibrate phone on incorrect passcode input (bool)
	},
	
	// properties for the window
	mainWindow: {
		backgroundImage: 'bg.png'
		/*backgroundColor: '#000000',
		backgroundGradient:{
			type: 'linear', 
			colors: ['#666666', '#000000'], 
			startPoint: {x:0, y:0}, 
			endPoint: {x:0, y:350}
		}*/
	},	
	
	// properties for the messageBox
	messageBox: {
		text: 'Enter Unlock Code',
		textCorrect: 'Unlock Code Accepted',
		textIncorrect: 'Wrong Unlock Code',
		textColorCorrect: '#ffffff',
		textColorIncorrect: '#ff0000',
		vibrateOnIncorrect: true,
		borderColor: '#ffffff',	
		backgroundColor: 'gray',
		font: {
			fontFamily: 'Helvetica Neue',
			fontWeight: 'bold',
			fontSize: 20
		},
	},
	
	// properties for the passwordBox
	passwordBox: {
		top: 145,
		width: 50,
		gapWidth: 20	
	},
	
	// properties for the timeOutBox
	timeOutBox: {
		text: 'Please try again in',
		top: 185,
		color: '#ffffff',
		font: {
			fontFamily: 'Helvetica Neue',
			fontWeight: 'bold',
			fontSize: 18
		},	
	},
	
	// do something	on correct passcode
	correct: function() {  	
      	// for instance set your own custom alert
      	alert('Yes, your passcode is correct!');
    },
    
    // do something	on incorrect passcode
   	incorrect: function() {
		// for instance set your own custom alert			
    	alert('Ooops, looks like the insert code is incorrect...Please try again');
   	}
});