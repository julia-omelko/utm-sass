// open a single window
var window = Ti.UI.createWindow({
	backgroundColor: 'white'
});

var button = Ti.UI.createButton({
	height: 40,
   	width: Ti.Platform.displayCaps.platformWidth-40,
   	top: 20,
   	left: 20,
   	title: 'Open Unlock Window'
});

button.addEventListener('click',function() {
   unlockWindow.open();
});

window.add(button);
window.open();

// load the module
var unlockScreen = require('com.qbset.unlockscreen');
Ti.API.info("module is => " + unlockScreen);

// load the unlockScreen window
var unlockWindow = unlockScreen.loadWindow({
	// main properties for the module
	configLockScreen: { // main properties for the module
		passCode: '1234', // set the passcode (string)
		attempts: 3, // zero for infinite attempts and no timeout (int)
		timeOut: 5000, // time out in miliseconds after amount of incorrect attempts. Only when attempts is bigger then zero (int)
		timeOutMultiplier: 2, // after each set of attempts the time out is multiplied with this property (int)
		vibrateOnIncorrect: true // vibrate phone on incorrect passcode input (bool)
	}
});